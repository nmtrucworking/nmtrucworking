# Bộ tài liệu cập nhật Portfolio — Nguyễn Minh Trúc

**Repo mục tiêu:** `nmtrucworking/nmtrucworking`  
**Phạm vi:** chuẩn hóa danh tính cá nhân, loại bỏ “JIN” khỏi vai trò thương hiệu, cập nhật nội dung song ngữ, metadata, SEO và quy tắc kiểm chứng case study.  
**Snapshot dùng để rà soát:** commit `52849526c32fe3819849e5bb6e34e5ff2d0bfa82`, ngày rà soát 2026-07-21.

## 1. Quyết định đã chốt

Portfolio **không sử dụng một tên thương hiệu độc lập**.

| Lớp nhận diện | Giá trị chuẩn |
|---|---|
| Danh tính chính thức | **Nguyễn Minh Trúc** |
| Dạng không dấu dùng cho kỹ thuật/SEO phụ | **Nguyen Minh Truc** |
| Tên giao tiếp trong nội dung tiếng Việt | **Trúc** |
| Wordmark kỹ thuật ngắn | **NMTRUC** |
| GitHub handle | `nmtrucworking` |
| Email nghề nghiệp | `nmtruc.work@gmail.com` |
| Dòng định vị | `Information Systems × Data × Product` |
| Motif/ý niệm thiết kế | `Systems in Motion` |

`NMTRUC` chỉ là wordmark rút gọn từ tên thật, không phải một thương hiệu hoặc nhân vật thứ hai. `Systems in Motion` là motif biên tập, không được trình bày như tên công ty.

## 2. Cấu trúc tài liệu

1. `01_IDENTITY_ARCHITECTURE.md` — kiến trúc tên gọi và quy tắc sử dụng.
2. `02_REPOSITORY_AUDIT.md` — kiểm kê lỗi hiện tại theo file.
3. `03_CONTENT_COPY_SPEC.md` — nội dung giao diện tiếng Việt và tiếng Anh.
4. `04_FILE_CHANGE_PLAN.md` — kế hoạch thay đổi từng file.
5. `05_SEO_METADATA_SOCIAL.md` — metadata, canonical, Open Graph và structured data.
6. `06_DATA_MIGRATION.md` — hướng dẫn thay dữ liệu JSON và đổi asset.
7. `07_EVIDENCE_INTEGRITY.md` — quy tắc không thổi phồng case study.
8. `08_QA_ACCEPTANCE_CHECKLIST.md` — điều kiện nghiệm thu.
9. `proposed/` — các file JSON mẫu đã chuẩn hóa.
10. `snippets/` — đoạn mã thay thế trọng yếu.

## 3. Trình tự triển khai

1. Tạo branch `chore/identity-normalization`.
2. Thay dữ liệu trong `src/content/data/`.
3. Cập nhật `Header`, trang chủ, `Footer` và root metadata.
4. Đổi tên file CV và các đường dẫn tương ứng.
5. Thay toàn bộ SEO title trong `projects.json`.
6. Đổi package name và tài liệu nội bộ.
7. Rà soát mức độ xác minh của từng case study.
8. Chạy kiểm tra dữ liệu, build và tìm kiếm chuỗi cũ.

## 4. Lệnh kiểm tra cuối

```bash
npm run validate-data
npm run build

rg -n -i '\bjin\b|jin-systems|hello@jin|jin-cv|jin-portfolio' \
  --glob '!node_modules/**' \
  --glob '!.next/**' \
  src public README.md package.json package-lock.json docs/portfolio
```

Kết quả kỳ vọng của lệnh `rg`: không còn kết quả trong mã nguồn đang chạy. Tên cũ chỉ được giữ trong lịch sử Git, không giữ trong thư mục tài liệu hiện hành.


---

# Kiến trúc danh tính và quy tắc gọi tên

## 1. Vấn đề cần giải quyết

Repo đang dùng đồng thời `JIN`, `Jin`, `NMTRUC`, `nmtrucworking` và Nguyễn Minh Trúc. Các định danh này chưa có quan hệ phân cấp rõ ràng, khiến recruiter hoặc khách hàng phải tự suy luận liệu đây là một người, một studio hay nhiều thực thể.

Ngoài ra, `JIN` là chuỗi ngắn, phổ biến và có độ phân biệt thấp. Dùng nó làm thương hiệu độc lập tạo bất lợi cho tìm kiếm, xác minh danh tính và khả năng đồng bộ với CV, LinkedIn, GitHub và email.

## 2. Mô hình danh tính chuẩn

```text
Nguyễn Minh Trúc                      ← danh tính duy nhất
├── Trúc                              ← cách gọi trong văn bản tiếng Việt
├── Nguyen Minh Truc                  ← alias không dấu cho tìm kiếm
├── NMTRUC                            ← wordmark giao diện
└── nmtrucworking                     ← handle nền tảng
```

Không tạo thêm lớp “brand name”.

## 3. Quy tắc theo ngữ cảnh

| Ngữ cảnh | Giá trị phải dùng |
|---|---|
| Hero, About, CV, LinkedIn | Nguyễn Minh Trúc |
| Metadata tiếng Anh | Nguyễn Minh Trúc; thêm alias `Nguyen Minh Truc` trong keywords/structured data |
| Header wordmark | NMTRUC |
| Favicon/monogram | `NM` hoặc `NMT`, ưu tiên `NM` nếu kích thước rất nhỏ |
| GitHub và liên kết kỹ thuật | `@nmtrucworking` |
| Văn phong ngôi thứ nhất tiếng Việt | “Tôi là Trúc…” chỉ dùng một lần ở phần About |
| Copyright | `© {year} Nguyễn Minh Trúc` |
| Tác giả dự án | `Nguyễn Minh Trúc` |
| Tên repository/package | `nmtruc-portfolio` |

## 4. Vai trò của “Systems in Motion”

Được giữ như một **editorial concept** mô tả cách tiếp cận hệ thống:

```text
INPUT → INTERPRET → STRUCTURE → BUILD → EVALUATE
```

Không sử dụng theo các dạng:

- `JIN / Systems in Motion`
- `Systems in Motion by JIN`
- `JIN Systems`
- `JIN Studio`

Được phép sử dụng:

- Badge nhỏ trên hero: `SYSTEMS IN MOTION`
- Tên motif trong design system
- Nhãn tiến trình của case study

## 5. Wordmark đề xuất

### Desktop

```text
NMTRUC
PERSONAL PORTFOLIO
```

### Mobile

```text
NM
```

### Không sử dụng

```text
J
JIN
JIN / TRÚC
JIN TRÚC
NMT STUDIO
```

## 6. Nguyên tắc chống nhầm lẫn

1. Tên đầy đủ phải xuất hiện trong viewport đầu tiên của trang chủ.
2. Wordmark phải dẫn về trang chủ nhưng không thay thế tên đầy đủ trong nội dung.
3. Không dùng `Trúc` như một thương hiệu viết hoa toàn bộ.
4. Không sử dụng một email hiển thị khác email thật.
5. Tên trong CV, LinkedIn, GitHub profile README, Open Graph và structured data phải cùng quy về Nguyễn Minh Trúc.


---

# Rà soát repo hiện tại

## 1. Kết luận chính

Mã nguồn hiện tại đã triển khai một hệ thống dữ liệu tương đối rõ, nhưng danh tính `JIN` bị hard-code ở nhiều lớp: cấu hình site, profile, bản dịch, component, metadata, SEO dự án, package và tài liệu nội bộ. Chỉ thay logo sẽ không giải quyết triệt để.

## 2. Kiểm kê theo file

| File | Hiện trạng | Thay đổi bắt buộc |
|---|---|---|
| `src/content/data/site.json` | `siteName: "JIN / Systems in Motion"`, domain `jin-systems.dev` | Đổi site name; thay production domain thật; loại social placeholder |
| `src/content/data/profile.json` | `id: "jin"`, `displayName: "Jin"`, CV tên `jin-cv-*` | Đổi thành `nguyen-minh-truc`, tên đầy đủ và tên file CV mới |
| `src/content/data/messages.en.json` | `About Jin`, email lỗi dùng `hello@jin-systems.dev` | Đổi About title và dùng email thật |
| `src/content/data/messages.vi.json` | `Về Jin`, email lỗi dùng `hello@jin-systems.dev` | Đổi thành `Về Nguyễn Minh Trúc`; dùng email thật |
| `src/app/layout.tsx` | metadata title hard-code `JIN / Systems in Motion` | Dùng tên thật và metadata template |
| `src/components/layout/Header.tsx` | monogram `J`, wordmark `JIN` | Dùng `NM`/`NMTRUC` |
| `src/components/layout/Footer.tsx` | copyright `JIN` | Dùng Nguyễn Minh Trúc |
| `src/app/[locale]/page.tsx` | ảnh đã dùng `nmtruc.png`, nhãn `OPERATOR // NMTRUC`; hero chưa hiển thị tên đầy đủ | Thêm identity label/tên đầy đủ; chuẩn hóa nhãn ảnh |
| `src/content/data/projects.json` | nhiều `seoTitle` kết thúc bằng `— Jin` | Đổi thành `— Nguyễn Minh Trúc` |
| `README.md` | “I'm Jin”, email/LinkedIn label giả định | Viết lại theo tên thật và URL thật |
| `package.json` | `name: "jin-portfolio"` | Đổi thành `nmtruc-portfolio` |
| `package-lock.json` | giữ package name cũ | Chạy `npm install` sau khi đổi package |
| `JIN_Portfolio_Implementation_Docs/` | tên thư mục và nội dung neo vào JIN | Đổi thành `docs/portfolio/` và cập nhật nội dung |

## 3. Social link không nên giữ nếu chưa dùng

`site.json` hiện chứa Twitter, Instagram và Facebook. Nếu các kênh này không phục vụ mục tiêu nghề nghiệp hoặc URL chỉ là placeholder, nên xóa khỏi dữ liệu thay vì để liên kết rỗng/không chính xác.

Kênh tối thiểu:

- GitHub
- LinkedIn
- Email

## 4. Rủi ro nội dung ngoài phạm vi tên gọi

Một số case study dùng:

- trạng thái `production`;
- chỉ số tác động kinh doanh cụ thể;
- số đo hiệu năng/kiểm thử;
- mô tả như một hệ thống đã vận hành thực tế.

Nếu các số liệu là dữ liệu minh họa, mô phỏng hoặc mục tiêu thiết kế, chúng phải được gắn nhãn tương ứng. Portfolio cá nhân chịu rủi ro lớn hơn từ một claim không chứng minh được so với việc thiếu một metric.

## 5. Mức ưu tiên

### P0 — chặn phát hành

- Tên người, metadata, CV, email hiển thị.
- Các liên kết giả/placeholder.
- Metric hoặc trạng thái dự án sai bản chất.

### P1 — cần hoàn thành trong cùng nhánh

- Header, Footer, README, project SEO titles.
- Package name và docs directory.

### P2 — cải thiện tiếp theo

- Structured data.
- Sitemap/canonical theo locale.
- Chuẩn hóa author và evidence model trong schema.


---

# Nội dung giao diện chuẩn hóa

## 1. Header

### Wordmark

```text
NMTRUC
PERSONAL PORTFOLIO
```

Bản tiếng Việt và tiếng Anh dùng cùng wordmark. Không dịch `NMTRUC`.

## 2. Hero

### English

**Identity label**

```text
NGUYEN MINH TRUC
```

**Heading**

```text
Designing data-informed systems and products.
```

**Lead**

```text
I turn ambiguous requirements into structures that teams can understand, build, test, and improve.
```

**Descriptor**

```text
Information Systems × Data × Product
```

### Tiếng Việt

**Identity label**

```text
NGUYỄN MINH TRÚC
```

**Heading**

```text
Thiết kế hệ thống và sản phẩm dựa trên dữ liệu.
```

**Lead**

```text
Tôi chuyển các yêu cầu chưa rõ ràng thành cấu trúc mà đội ngũ có thể hiểu, triển khai, kiểm thử và cải tiến.
```

**Descriptor**

```text
Hệ thống Thông tin × Dữ liệu × Sản phẩm
```

## 3. About

### English title

```text
About Nguyen Minh Truc
```

### Vietnamese title

```text
Về Nguyễn Minh Trúc
```

### English introductory paragraph

```text
I am an Information Systems student working across data analysis, system analysis, and product development. My portfolio focuses on how requirements, data, architecture, and user outcomes connect—not on presenting isolated tools as expertise.
```

### Vietnamese introductory paragraph

```text
Tôi là Nguyễn Minh Trúc, sinh viên Hệ thống thông tin, tập trung vào phân tích dữ liệu, phân tích hệ thống và phát triển sản phẩm. Portfolio này trình bày mối liên hệ giữa yêu cầu, dữ liệu, kiến trúc và kết quả người dùng, thay vì liệt kê công cụ như những năng lực tách rời.
```

## 4. Contact

### English

```text
Have a system, data, or product problem that requires structured analysis? Contact me with the context, constraints, and expected outcome.
```

### Tiếng Việt

```text
Bạn có một bài toán hệ thống, dữ liệu hoặc sản phẩm cần được phân tích có cấu trúc? Hãy gửi bối cảnh, ràng buộc và kết quả mong đợi.
```

Email hiển thị và email thực tế đều là:

```text
nmtruc.work@gmail.com
```

## 5. Footer

### English

```text
© 2026 Nguyen Minh Truc. All rights reserved.
```

### Tiếng Việt

```text
© 2026 Nguyễn Minh Trúc. Giữ toàn bộ bản quyền.
```

## 6. SEO title format

### Home

```text
Nguyễn Minh Trúc — Information Systems, Data & Product
```

### Work

```text
Selected Work — Nguyễn Minh Trúc
```

### Project

```text
{Project title} — Nguyễn Minh Trúc
```

### About

```text
About Nguyễn Minh Trúc
```

## 7. Giọng văn

- Dùng động từ mô tả hành động: defined, modeled, analyzed, implemented, evaluated.
- Không tự nhận “expert”, “specialist”, “highly skilled” nếu chưa có bằng chứng độc lập.
- Phân biệt rõ `designed`, `implemented`, `tested`, `deployed` và `operated`.
- Không dùng “we” cho dự án cá nhân; không dùng “I” cho phần việc của cả đội.
- Mỗi case study phải chỉ rõ phạm vi đóng góp cá nhân.


---

# Kế hoạch thay đổi theo file

## 1. `src/content/data/site.json`

Dùng file mẫu tại:

```text
proposed/src/content/data/site.template.json
```

Điểm bắt buộc:

- `siteName`: `Nguyễn Minh Trúc — Portfolio`
- `baseUrl`: thay bằng domain production thật trước khi merge.
- Chỉ giữ social link đã xác minh.

## 2. `src/content/data/profile.json`

Dùng file mẫu:

```text
proposed/src/content/data/profile.json
```

Đổi asset CV:

```text
public/cv/jin-cv-en.pdf
→ public/cv/nguyen-minh-truc-cv-en.pdf

public/cv/jin-cv-vi.pdf
→ public/cv/nguyen-minh-truc-cv-vi.pdf
```

## 3. `messages.en.json` và `messages.vi.json`

Có file thay thế đầy đủ trong `proposed/`. Các thay đổi trọng yếu:

- `About Jin` → `About Nguyen Minh Truc`
- `Về Jin` → `Về Nguyễn Minh Trúc`
- bỏ email `hello@jin-systems.dev`
- rút gọn nhãn CTA, tránh ngôn ngữ agency quá mức như “Initiate Contact”.

## 4. `src/app/layout.tsx`

Dùng snippet:

```text
snippets/layout.metadata.ts
```

Nên mở rộng metadata bằng `metadataBase`, template title, Open Graph, Twitter card và authors.

## 5. `src/components/layout/Header.tsx`

Thay block brand mark bằng snippet:

```text
snippets/Header.brand.tsx
```

Không thay đổi navigation hoặc locale switcher.

## 6. `src/app/[locale]/page.tsx`

Thay phần đầu hero theo cấu trúc:

```tsx
<p className="mono-label">{profile.displayName}</p>
<h1>{localized hero heading}</h1>
<p>{profile.positioningText}</p>
```

Thay nhãn ảnh:

```text
OPERATOR // NMTRUC
→ PROFILE // NGUYEN_MINH_TRUC
```

`alt` phải luôn nhận `profile.displayName`; fallback là `Nguyễn Minh Trúc`.

## 7. `src/components/layout/Footer.tsx`

Thay copyright:

```tsx
© {new Date().getFullYear()} {profile.displayName}. {messages.footer.rights}
```

Không hard-code tên trong component khi dữ liệu profile đã có.

## 8. `src/content/data/projects.json`

Thực hiện thay thế có kiểm soát:

```text
— Jin
→ — Nguyễn Minh Trúc
```

Sau đó rà soát từng project:

- URL repository có trỏ đúng repo dự án không.
- `stage` có phản ánh thực tế không.
- Metric có nguồn kiểm chứng không.
- `team.size` và contribution có chính xác không.

Không chạy global replace cho các từ “jin” nằm trong URL lịch sử nếu URL đó thực sự cần giữ. Tuy nhiên `jin-systems.dev` phải bị loại bỏ hoàn toàn.

## 9. `package.json`

```json
{
  "name": "nmtruc-portfolio"
}
```

Sau đó chạy:

```bash
npm install
```

để đồng bộ `package-lock.json`.

## 10. Tài liệu nội bộ

Đổi:

```text
JIN_Portfolio_Implementation_Docs/jin-portfolio-docs/
```

thành:

```text
docs/portfolio/
```

Các file trong thư mục cũ phải được cập nhật theo `01_IDENTITY_ARCHITECTURE.md`; không chỉ đổi tên thư mục.

## 11. README

Dùng nội dung mẫu:

```text
snippets/README.replacement.md
```

## 12. Commit đề xuất

```text
chore(identity): replace JIN branding with Nguyen Minh Truc identity
```


---

# SEO, metadata và social identity

## 1. Mục tiêu

Công cụ tìm kiếm phải nhận biết portfolio thuộc về **một cá nhân cụ thể**, không phải một thương hiệu tên JIN.

## 2. Metadata chuẩn

```ts
export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL!),
  title: {
    default: 'Nguyễn Minh Trúc — Information Systems, Data & Product',
    template: '%s — Nguyễn Minh Trúc',
  },
  description:
    'Bilingual portfolio of Nguyễn Minh Trúc, focused on information systems, data analysis, system analysis, and product development.',
  authors: [{ name: 'Nguyễn Minh Trúc' }],
  creator: 'Nguyễn Minh Trúc',
  keywords: [
    'Nguyễn Minh Trúc',
    'Nguyen Minh Truc',
    'nmtrucworking',
    'Information Systems',
    'Data Analyst',
    'System Analyst',
    'Business Analyst',
    'Data Science',
  ],
};
```

Không dùng `!` với biến môi trường nếu build pipeline chưa đảm bảo biến luôn tồn tại. Có thể dùng fallback local cho development, nhưng production phải fail nếu thiếu canonical URL.

## 3. Canonical và locale

Mỗi route cần:

- canonical URL;
- alternate `en` và `vi`;
- `x-default` trỏ về locale mặc định;
- Open Graph locale tương ứng.

Ví dụ logic:

```ts
alternates: {
  canonical: `/${locale}`,
  languages: {
    en: '/en',
    vi: '/vi',
    'x-default': '/en',
  },
}
```

## 4. Person structured data

```json
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Nguyễn Minh Trúc",
  "alternateName": ["Nguyen Minh Truc", "NMTRUC", "nmtrucworking"],
  "email": "mailto:nmtruc.work@gmail.com",
  "url": "REPLACE_WITH_PRODUCTION_URL",
  "sameAs": [
    "https://github.com/nmtrucworking",
    "https://www.linkedin.com/in/minh-truc-nguyen/"
  ],
  "knowsAbout": [
    "Information Systems",
    "Data Analysis",
    "System Analysis",
    "Business Analysis",
    "Data Science",
    "Product Development"
  ]
}
```

Không thêm trường `jobTitle` chứa năm vai trò cùng lúc. Điều đó làm định vị thiếu trọng tâm. Có thể dùng mô tả rộng ở `description`, còn từng case study thể hiện role lens.

## 5. Open Graph image

Ảnh OG nên có:

- Nguyễn Minh Trúc
- `Information Systems × Data × Product`
- URL/handle `nmtrucworking`
- không dùng logo JIN

Kích thước: `1200 × 630`.

## 6. Social profile consistency

| Nền tảng | Display name | Handle/URL |
|---|---|---|
| Portfolio | Nguyễn Minh Trúc | production domain |
| GitHub | Nguyễn Minh Trúc | `nmtrucworking` |
| LinkedIn | Nguyễn Minh Trúc | existing LinkedIn URL |
| Email | Nguyễn Minh Trúc | `nmtruc.work@gmail.com` |

Avatar, headline và short bio nên dùng cùng một ảnh chân dung và cùng ba trụ cột định vị.

## 7. Domain

Không phát hành với `jin-systems.dev` nếu domain đó không còn là định danh chiến lược hoặc chưa thuộc quyền kiểm soát.

Tiêu chí chọn domain:

1. chứa `nmtruc`, `minhtruc` hoặc tên đầy đủ;
2. dễ đọc khi nói thành tiếng;
3. không cần giải thích quan hệ với tên thật;
4. có thể dùng đồng nhất trong email và social bio;
5. đã xác minh quyền sở hữu trước khi đưa vào metadata.


---

# Hướng dẫn migration dữ liệu

## 1. Nguyên tắc

Source of truth của danh tính phải nằm trong `profile.json` và `site.json`. Component chỉ render dữ liệu; không hard-code lại tên trừ fallback accessibility.

## 2. Thứ tự thay file

```bash
cp proposed/src/content/data/profile.json src/content/data/profile.json
cp proposed/src/content/data/messages.en.json src/content/data/messages.en.json
cp proposed/src/content/data/messages.vi.json src/content/data/messages.vi.json
```

Với `site.template.json`, phải thay `REPLACE_WITH_PRODUCTION_DOMAIN` trước rồi mới copy.

## 3. Đổi tên CV

```bash
mv public/cv/jin-cv-en.pdf public/cv/nguyen-minh-truc-cv-en.pdf
mv public/cv/jin-cv-vi.pdf public/cv/nguyen-minh-truc-cv-vi.pdf
```

Nếu file CV chưa tồn tại, không tạo file giả. Giữ trang CV ở trạng thái `coming soon` hoặc ẩn CTA tải xuống cho đến khi có artifact thật.

## 4. Thay SEO title trong projects

Dùng script có review diff:

```bash
python -c "from pathlib import Path; p=Path('src/content/data/projects.json'); s=p.read_text(encoding='utf-8').replace('— Jin','— Nguyễn Minh Trúc'); p.write_text(s, encoding='utf-8')"
git diff -- src/content/data/projects.json
```

Không tự động thay metric hoặc project status.

## 5. Domain configuration

Khuyến nghị đưa domain vào environment:

```env
NEXT_PUBLIC_SITE_URL=https://your-production-domain.example
```

Sau đó metadata và JSON-LD đọc từ biến này. Nếu `site.json` vẫn cần `baseUrl`, build script nên kiểm tra `baseUrl` trùng `NEXT_PUBLIC_SITE_URL` ở production.

## 6. Validation

```bash
npm run validate-data
npm run build
```

Nếu JSON schema thất bại:

- kiểm tra URI có scheme `https://`;
- kiểm tra `id` chỉ dùng chữ thường, số và dấu gạch ngang;
- không thêm property ngoài schema;
- giữ đủ hai locale `en` và `vi`.

## 7. Data ownership rule

Các trường sau không được trùng lặp ở nhiều file nếu không cần thiết:

- tên cá nhân;
- email;
- GitHub URL;
- LinkedIn URL;
- base URL.

Ở vòng cải tiến tiếp theo, nên tạo một selector hoặc config chung cho metadata để giảm drift giữa `profile.json`, `site.json` và `layout.tsx`.


---

# Quy tắc kiểm chứng nội dung case study

## 1. Lý do

Portfolio đang nhắm đến recruiter, khách hàng freelance và đối tác dự án. Ba nhóm này đánh giá cao tính truy xuất được của bằng chứng. Claim không kiểm chứng làm giảm độ tin cậy của toàn bộ hồ sơ, kể cả những phần đúng.

## 2. Phân loại trạng thái dự án

| Trạng thái hiển thị | Điều kiện tối thiểu |
|---|---|
| `concept` | Có vấn đề, phạm vi và giải pháp dự kiến; chưa có prototype |
| `prototype` | Có artifact chạy được hoặc prototype có thể kiểm tra |
| `validated prototype` | Có test với người dùng/dữ liệu và phương pháp được mô tả |
| `production` | Đã triển khai cho người dùng thực hoặc quy trình vận hành thực |
| `archived` | Không còn phát triển; giữ để minh họa quá trình học |

Không dùng `production` chỉ vì mã nguồn build thành công.

## 3. Phân loại metric

Mỗi metric phải có một trong bốn nhãn nội bộ:

```text
MEASURED
DERIVED
TARGET
ILLUSTRATIVE
```

- **MEASURED:** đo trực tiếp từ hệ thống/dataset, có phương pháp.
- **DERIVED:** tính toán từ dữ liệu nguồn, có công thức.
- **TARGET:** mục tiêu thiết kế, chưa đạt.
- **ILLUSTRATIVE:** dữ liệu minh họa; không trình bày như kết quả thực.

UI public chỉ nên hiển thị `MEASURED` hoặc `DERIVED`. `TARGET` phải ghi rõ “Target”. `ILLUSTRATIVE` nên bị loại khỏi phần impact.

## 4. Checklist cho từng project

- [ ] Repo/link trỏ đúng project.
- [ ] Có README hoặc artifact mô tả cách chạy/xem.
- [ ] Role cá nhân được mô tả tách khỏi đóng góp nhóm.
- [ ] Stage phản ánh đúng mức triển khai.
- [ ] Mọi metric có nguồn và phương pháp.
- [ ] Không dùng kết quả mô phỏng như tác động kinh doanh thật.
- [ ] Không dùng phần trăm chính xác giả tạo nếu chỉ là ước lượng.
- [ ] Ảnh concept/mockup được gắn nhãn.
- [ ] Công nghệ liệt kê đã thực sự được dùng trong phần việc mô tả.

## 5. Cấu trúc bằng chứng đề xuất

Mỗi case study nên có:

1. Context
2. Constraints
3. My role
4. Decisions
5. Artifacts
6. Validation
7. Result
8. Limitations
9. Next step

## 6. Các câu nên tránh

```text
Achieved 0% data leakage.
Reduced churn by 18%.
Ready for horizontal microservice scaling.
```

trừ khi có kiểm thử, dữ liệu và phạm vi chứng minh.

Dạng an toàn hơn khi chưa đủ bằng chứng:

```text
Designed tenant isolation rules and test cases intended to prevent cross-tenant access.

Evaluated the model on a held-out dataset; business retention impact has not yet been measured.

Defined service boundaries and scaling assumptions for a future microservice deployment.
```


---

# QA và điều kiện nghiệm thu

## 1. Identity consistency

- [ ] Header hiển thị `NMTRUC`, không hiển thị `JIN`.
- [ ] Tên đầy đủ xuất hiện trong viewport đầu tiên.
- [ ] About hiển thị Nguyễn Minh Trúc.
- [ ] Footer copyright dùng tên đầy đủ.
- [ ] CV và nút tải CV dùng tên file mới.
- [ ] README dùng tên đầy đủ.
- [ ] Không có persona thứ hai tên Jin.

## 2. Search residue

Chạy:

```bash
rg -n -i '\bjin\b|jin-systems|hello@jin|jin-cv|jin-portfolio' \
  --glob '!node_modules/**' \
  --glob '!.next/**' \
  src public README.md package.json package-lock.json docs/portfolio
```

- [ ] Không còn chuỗi cũ trong source runtime.
- [ ] Không còn chuỗi cũ trong JSON examples.
- [ ] Không còn thư mục docs mang tên JIN.
- [ ] `package-lock.json` đã đồng bộ.

## 3. Data/build

- [ ] `npm run validate-data` thành công.
- [ ] `npm run build` thành công.
- [ ] Không có broken link.
- [ ] Không có social placeholder.
- [ ] CV PDF tồn tại đúng đường dẫn.

## 4. SEO

- [ ] Metadata title có tên đầy đủ.
- [ ] Description mô tả đúng phạm vi nghề nghiệp.
- [ ] Canonical dùng domain production thật.
- [ ] Locale alternates đúng.
- [ ] Open Graph image không chứa JIN.
- [ ] JSON-LD `Person` hợp lệ.
- [ ] Project SEO title dùng Nguyễn Minh Trúc.

## 5. Accessibility

- [ ] Wordmark link có accessible name rõ.
- [ ] Ảnh chân dung alt là Nguyễn Minh Trúc.
- [ ] Social icon có `aria-label`.
- [ ] Locale switcher đọc được bằng screen reader.
- [ ] Contrast của signal color đạt yêu cầu ở ngữ cảnh sử dụng.
- [ ] Focus state hiển thị rõ.

## 6. Responsive

Kiểm tra tối thiểu:

- 360 × 800
- 768 × 1024
- 1280 × 800
- 1440 × 900

- [ ] `NMTRUC` không đẩy navigation tràn màn hình.
- [ ] Tên đầy đủ không bị cắt sai.
- [ ] Hero portrait không che headline.
- [ ] Song ngữ không tạo layout shift nghiêm trọng.

## 7. Evidence integrity

- [ ] Không có project `production` nếu chưa triển khai thực.
- [ ] Metric public có phương pháp và nguồn.
- [ ] Mockup/concept có nhãn.
- [ ] Link repository đúng project.
- [ ] Contribution cá nhân không nhận công của cả đội.

## 8. Definition of Done

Một nhánh chỉ được merge khi:

1. toàn bộ P0 hoàn thành;
2. validate-data và build đều pass;
3. không còn residue JIN trong runtime/docs hiện hành;
4. domain, email, LinkedIn và GitHub đã xác minh;
5. case study không chứa claim sai trạng thái hoặc chưa kiểm chứng.


---

# Prompt triển khai dành cho coding agent

Sử dụng prompt này sau khi đặt bộ tài liệu bên ngoài repo hoặc cung cấp trực tiếp cho coding agent.

```text
Repository: nmtrucworking/nmtrucworking
Branch to create: chore/identity-normalization

Goal:
Normalize the portfolio around one professional identity: Nguyễn Minh Trúc. Remove JIN as a public brand or persona. Use NMTRUC only as a compact wordmark derived from the real name. Retain “Systems in Motion” only as an editorial motif.

Authoritative documents:
- 01_IDENTITY_ARCHITECTURE.md
- 03_CONTENT_COPY_SPEC.md
- 04_FILE_CHANGE_PLAN.md
- 05_SEO_METADATA_SOCIAL.md
- 06_DATA_MIGRATION.md
- 07_EVIDENCE_INTEGRITY.md
- 08_QA_ACCEPTANCE_CHECKLIST.md

Required changes:
1. Replace site/profile/messages data using the proposed JSON files. Replace the placeholder baseUrl with the actual production URL; do not publish example.com.
2. Update root metadata, Header brand block, Hero identity block, Footer copyright, README, package name, CV paths, and project SEO titles.
3. Make profile.json/site.json the identity source of truth. Avoid hard-coded duplicate names when data selectors can provide them.
4. Remove unverified or placeholder social links.
5. Rename the old JIN documentation directory to docs/portfolio and normalize its active content.
6. Do not automatically promote or rewrite project claims. For every production status or quantitative outcome without visible evidence, downgrade the public claim or create a review note. Do not invent evidence.
7. Preserve the current visual system, responsive behavior, locale routing, and JSON schema structure unless a change is explicitly required by the documents.

Validation:
- npm run validate-data
- npm run build
- run the residue search defined in 08_QA_ACCEPTANCE_CHECKLIST.md
- review git diff for accidental changes

Deliverable:
Provide a concise change summary, list any unresolved domain/CV/evidence decisions, and report validation results. Do not commit directly to main.
```


---
