# Kiến trúc danh tính và quy tắc gọi tên

## 1. Vấn đề cần giải quyết

Repo đang dùng đồng thời `JIN`, `Jin`, `NMTRUC`, `nmtrucworking` và Nguyễn Minh Trúc. Các định danh này chưa có quan hệ phân cấp rõ ràng, khiến recruiter hoặc khách hàng phải tự suy luận liệu đây là một người, một studio hay nhiều thực thể.

Ngoài ra, `JIN` là chuỗi ngắn, phổ biến và có độ phân biệt thấp. Dùng nó làm thương hiệu độc lập tạo bất lợi cho tìm kiếm, xác minh danh tính và khả năng đồng bộ với CV, LinkedIn, GitHub và email.

## 2. Mô hình danh tính chuẩn

```text
Nguyễn Minh Trúc                      ← danh tính duy nhất
├── Trúc                              ← cách gọi trong văn bản tiếng Việt
├── Nguyen Minh Truc                  ← alias không dấu cho tìm kiếm
├── NMTRUC                            ← wordmark giao diện
└── nmtrucworking                     ← handle nền tảng
```

Không tạo thêm lớp “brand name”.

## 3. Quy tắc theo ngữ cảnh

| Ngữ cảnh | Giá trị phải dùng |
|---|---|
| Hero, About, CV, LinkedIn | Nguyễn Minh Trúc |
| Metadata tiếng Anh | Nguyễn Minh Trúc; thêm alias `Nguyen Minh Truc` trong keywords/structured data |
| Header wordmark | NMTRUC |
| Favicon/monogram | `NM` hoặc `NMT`, ưu tiên `NM` nếu kích thước rất nhỏ |
| GitHub và liên kết kỹ thuật | `@nmtrucworking` |
| Văn phong ngôi thứ nhất tiếng Việt | “Tôi là Trúc…” chỉ dùng một lần ở phần About |
| Copyright | `© {year} Nguyễn Minh Trúc` |
| Tác giả dự án | `Nguyễn Minh Trúc` |
| Tên repository/package | `nmtruc-portfolio` |

## 4. Vai trò của “Systems in Motion”

Được giữ như một **editorial concept** mô tả cách tiếp cận hệ thống:

```text
INPUT → INTERPRET → STRUCTURE → BUILD → EVALUATE
```

Không sử dụng theo các dạng:

- `JIN / Systems in Motion`
- `Systems in Motion by JIN`
- `JIN Systems`
- `JIN Studio`

Được phép sử dụng:

- Badge nhỏ trên hero: `SYSTEMS IN MOTION`
- Tên motif trong design system
- Nhãn tiến trình của case study

## 5. Wordmark đề xuất

### Desktop

```text
NMTRUC
PERSONAL PORTFOLIO
```

### Mobile

```text
NM
```

### Không sử dụng

```text
J
JIN
JIN / TRÚC
JIN TRÚC
NMT STUDIO
```

## 6. Nguyên tắc chống nhầm lẫn

1. Tên đầy đủ phải xuất hiện trong viewport đầu tiên của trang chủ.
2. Wordmark phải dẫn về trang chủ nhưng không thay thế tên đầy đủ trong nội dung.
3. Không dùng `Trúc` như một thương hiệu viết hoa toàn bộ.
4. Không sử dụng một email hiển thị khác email thật.
5. Tên trong CV, LinkedIn, GitHub profile README, Open Graph và structured data phải cùng quy về Nguyễn Minh Trúc.
