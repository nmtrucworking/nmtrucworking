# QA và điều kiện nghiệm thu

## 1. Identity consistency

- [ ] Header hiển thị `NMTRUC`, không hiển thị `JIN`.
- [ ] Tên đầy đủ xuất hiện trong viewport đầu tiên.
- [ ] About hiển thị Nguyễn Minh Trúc.
- [ ] Footer copyright dùng tên đầy đủ.
- [ ] CV và nút tải CV dùng tên file mới.
- [ ] README dùng tên đầy đủ.
- [ ] Không có persona thứ hai tên Jin.

## 2. Search residue

Chạy:

```bash
rg -n -i '\bjin\b|jin-systems|hello@jin|jin-cv|jin-portfolio' \
  --glob '!node_modules/**' \
  --glob '!.next/**' \
  src public README.md package.json package-lock.json docs/portfolio
```

- [ ] Không còn chuỗi cũ trong source runtime.
- [ ] Không còn chuỗi cũ trong JSON examples.
- [ ] Không còn thư mục docs mang tên JIN.
- [ ] `package-lock.json` đã đồng bộ.

## 3. Data/build

- [ ] `npm run validate-data` thành công.
- [ ] `npm run build` thành công.
- [ ] Không có broken link.
- [ ] Không có social placeholder.
- [ ] CV PDF tồn tại đúng đường dẫn.

## 4. SEO

- [ ] Metadata title có tên đầy đủ.
- [ ] Description mô tả đúng phạm vi nghề nghiệp.
- [ ] Canonical dùng domain production thật.
- [ ] Locale alternates đúng.
- [ ] Open Graph image không chứa JIN.
- [ ] JSON-LD `Person` hợp lệ.
- [ ] Project SEO title dùng Nguyễn Minh Trúc.

## 5. Accessibility

- [ ] Wordmark link có accessible name rõ.
- [ ] Ảnh chân dung alt là Nguyễn Minh Trúc.
- [ ] Social icon có `aria-label`.
- [ ] Locale switcher đọc được bằng screen reader.
- [ ] Contrast của signal color đạt yêu cầu ở ngữ cảnh sử dụng.
- [ ] Focus state hiển thị rõ.

## 6. Responsive

Kiểm tra tối thiểu:

- 360 × 800
- 768 × 1024
- 1280 × 800
- 1440 × 900

- [ ] `NMTRUC` không đẩy navigation tràn màn hình.
- [ ] Tên đầy đủ không bị cắt sai.
- [ ] Hero portrait không che headline.
- [ ] Song ngữ không tạo layout shift nghiêm trọng.

## 7. Evidence integrity

- [ ] Không có project `production` nếu chưa triển khai thực.
- [ ] Metric public có phương pháp và nguồn.
- [ ] Mockup/concept có nhãn.
- [ ] Link repository đúng project.
- [ ] Contribution cá nhân không nhận công của cả đội.

## 8. Definition of Done

Một nhánh chỉ được merge khi:

1. toàn bộ P0 hoàn thành;
2. validate-data và build đều pass;
3. không còn residue JIN trong runtime/docs hiện hành;
4. domain, email, LinkedIn và GitHub đã xác minh;
5. case study không chứa claim sai trạng thái hoặc chưa kiểm chứng.
