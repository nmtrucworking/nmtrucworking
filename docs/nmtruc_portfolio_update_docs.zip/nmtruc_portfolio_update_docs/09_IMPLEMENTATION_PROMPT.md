# Prompt triển khai dành cho coding agent

Sử dụng prompt này sau khi đặt bộ tài liệu bên ngoài repo hoặc cung cấp trực tiếp cho coding agent.

```text
Repository: nmtrucworking/nmtrucworking
Branch to create: chore/identity-normalization

Goal:
Normalize the portfolio around one professional identity: Nguyễn Minh Trúc. Remove JIN as a public brand or persona. Use NMTRUC only as a compact wordmark derived from the real name. Retain “Systems in Motion” only as an editorial motif.

Authoritative documents:
- 01_IDENTITY_ARCHITECTURE.md
- 03_CONTENT_COPY_SPEC.md
- 04_FILE_CHANGE_PLAN.md
- 05_SEO_METADATA_SOCIAL.md
- 06_DATA_MIGRATION.md
- 07_EVIDENCE_INTEGRITY.md
- 08_QA_ACCEPTANCE_CHECKLIST.md

Required changes:
1. Replace site/profile/messages data using the proposed JSON files. Replace the placeholder baseUrl with the actual production URL; do not publish example.com.
2. Update root metadata, Header brand block, Hero identity block, Footer copyright, README, package name, CV paths, and project SEO titles.
3. Make profile.json/site.json the identity source of truth. Avoid hard-coded duplicate names when data selectors can provide them.
4. Remove unverified or placeholder social links.
5. Rename the old JIN documentation directory to docs/portfolio and normalize its active content.
6. Do not automatically promote or rewrite project claims. For every production status or quantitative outcome without visible evidence, downgrade the public claim or create a review note. Do not invent evidence.
7. Preserve the current visual system, responsive behavior, locale routing, and JSON schema structure unless a change is explicitly required by the documents.

Validation:
- npm run validate-data
- npm run build
- run the residue search defined in 08_QA_ACCEPTANCE_CHECKLIST.md
- review git diff for accidental changes

Deliverable:
Provide a concise change summary, list any unresolved domain/CV/evidence decisions, and report validation results. Do not commit directly to main.
```
