# Bộ tài liệu cập nhật Portfolio — Nguyễn Minh Trúc

**Repo mục tiêu:** `nmtrucworking/nmtrucworking`  
**Phạm vi:** chuẩn hóa danh tính cá nhân, loại bỏ “JIN” khỏi vai trò thương hiệu, cập nhật nội dung song ngữ, metadata, SEO và quy tắc kiểm chứng case study.  
**Snapshot dùng để rà soát:** commit `52849526c32fe3819849e5bb6e34e5ff2d0bfa82`, ngày rà soát 2026-07-21.

## 1. Quyết định đã chốt

Portfolio **không sử dụng một tên thương hiệu độc lập**.

| Lớp nhận diện | Giá trị chuẩn |
|---|---|
| Danh tính chính thức | **Nguyễn Minh Trúc** |
| Dạng không dấu dùng cho kỹ thuật/SEO phụ | **Nguyen Minh Truc** |
| Tên giao tiếp trong nội dung tiếng Việt | **Trúc** |
| Wordmark kỹ thuật ngắn | **NMTRUC** |
| GitHub handle | `nmtrucworking` |
| Email nghề nghiệp | `nmtruc.work@gmail.com` |
| Dòng định vị | `Information Systems × Data × Product` |
| Motif/ý niệm thiết kế | `Systems in Motion` |

`NMTRUC` chỉ là wordmark rút gọn từ tên thật, không phải một thương hiệu hoặc nhân vật thứ hai. `Systems in Motion` là motif biên tập, không được trình bày như tên công ty.

## 2. Cấu trúc tài liệu

1. `01_IDENTITY_ARCHITECTURE.md` — kiến trúc tên gọi và quy tắc sử dụng.
2. `02_REPOSITORY_AUDIT.md` — kiểm kê lỗi hiện tại theo file.
3. `03_CONTENT_COPY_SPEC.md` — nội dung giao diện tiếng Việt và tiếng Anh.
4. `04_FILE_CHANGE_PLAN.md` — kế hoạch thay đổi từng file.
5. `05_SEO_METADATA_SOCIAL.md` — metadata, canonical, Open Graph và structured data.
6. `06_DATA_MIGRATION.md` — hướng dẫn thay dữ liệu JSON và đổi asset.
7. `07_EVIDENCE_INTEGRITY.md` — quy tắc không thổi phồng case study.
8. `08_QA_ACCEPTANCE_CHECKLIST.md` — điều kiện nghiệm thu.
9. `proposed/` — các file JSON mẫu đã chuẩn hóa.
10. `snippets/` — đoạn mã thay thế trọng yếu.

## 3. Trình tự triển khai

1. Tạo branch `chore/identity-normalization`.
2. Thay dữ liệu trong `src/content/data/`.
3. Cập nhật `Header`, trang chủ, `Footer` và root metadata.
4. Đổi tên file CV và các đường dẫn tương ứng.
5. Thay toàn bộ SEO title trong `projects.json`.
6. Đổi package name và tài liệu nội bộ.
7. Rà soát mức độ xác minh của từng case study.
8. Chạy kiểm tra dữ liệu, build và tìm kiếm chuỗi cũ.

## 4. Lệnh kiểm tra cuối

```bash
npm run validate-data
npm run build

rg -n -i '\bjin\b|jin-systems|hello@jin|jin-cv|jin-portfolio' \
  --glob '!node_modules/**' \
  --glob '!.next/**' \
  src public README.md package.json package-lock.json docs/portfolio
```

Kết quả kỳ vọng của lệnh `rg`: không còn kết quả trong mã nguồn đang chạy. Tên cũ chỉ được giữ trong lịch sử Git, không giữ trong thư mục tài liệu hiện hành.
