# Quy tắc kiểm chứng nội dung case study

## 1. Lý do

Portfolio đang nhắm đến recruiter, khách hàng freelance và đối tác dự án. Ba nhóm này đánh giá cao tính truy xuất được của bằng chứng. Claim không kiểm chứng làm giảm độ tin cậy của toàn bộ hồ sơ, kể cả những phần đúng.

## 2. Phân loại trạng thái dự án

| Trạng thái hiển thị | Điều kiện tối thiểu |
|---|---|
| `concept` | Có vấn đề, phạm vi và giải pháp dự kiến; chưa có prototype |
| `prototype` | Có artifact chạy được hoặc prototype có thể kiểm tra |
| `validated prototype` | Có test với người dùng/dữ liệu và phương pháp được mô tả |
| `production` | Đã triển khai cho người dùng thực hoặc quy trình vận hành thực |
| `archived` | Không còn phát triển; giữ để minh họa quá trình học |

Không dùng `production` chỉ vì mã nguồn build thành công.

## 3. Phân loại metric

Mỗi metric phải có một trong bốn nhãn nội bộ:

```text
MEASURED
DERIVED
TARGET
ILLUSTRATIVE
```

- **MEASURED:** đo trực tiếp từ hệ thống/dataset, có phương pháp.
- **DERIVED:** tính toán từ dữ liệu nguồn, có công thức.
- **TARGET:** mục tiêu thiết kế, chưa đạt.
- **ILLUSTRATIVE:** dữ liệu minh họa; không trình bày như kết quả thực.

UI public chỉ nên hiển thị `MEASURED` hoặc `DERIVED`. `TARGET` phải ghi rõ “Target”. `ILLUSTRATIVE` nên bị loại khỏi phần impact.

## 4. Checklist cho từng project

- [ ] Repo/link trỏ đúng project.
- [ ] Có README hoặc artifact mô tả cách chạy/xem.
- [ ] Role cá nhân được mô tả tách khỏi đóng góp nhóm.
- [ ] Stage phản ánh đúng mức triển khai.
- [ ] Mọi metric có nguồn và phương pháp.
- [ ] Không dùng kết quả mô phỏng như tác động kinh doanh thật.
- [ ] Không dùng phần trăm chính xác giả tạo nếu chỉ là ước lượng.
- [ ] Ảnh concept/mockup được gắn nhãn.
- [ ] Công nghệ liệt kê đã thực sự được dùng trong phần việc mô tả.

## 5. Cấu trúc bằng chứng đề xuất

Mỗi case study nên có:

1. Context
2. Constraints
3. My role
4. Decisions
5. Artifacts
6. Validation
7. Result
8. Limitations
9. Next step

## 6. Các câu nên tránh

```text
Achieved 0% data leakage.
Reduced churn by 18%.
Ready for horizontal microservice scaling.
```

trừ khi có kiểm thử, dữ liệu và phạm vi chứng minh.

Dạng an toàn hơn khi chưa đủ bằng chứng:

```text
Designed tenant isolation rules and test cases intended to prevent cross-tenant access.

Evaluated the model on a held-out dataset; business retention impact has not yet been measured.

Defined service boundaries and scaling assumptions for a future microservice deployment.
```
