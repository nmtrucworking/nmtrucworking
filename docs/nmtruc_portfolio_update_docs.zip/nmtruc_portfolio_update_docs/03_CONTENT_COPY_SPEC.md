# Nội dung giao diện chuẩn hóa

## 1. Header

### Wordmark

```text
NMTRUC
PERSONAL PORTFOLIO
```

Bản tiếng Việt và tiếng Anh dùng cùng wordmark. Không dịch `NMTRUC`.

## 2. Hero

### English

**Identity label**

```text
NGUYEN MINH TRUC
```

**Heading**

```text
Designing data-informed systems and products.
```

**Lead**

```text
I turn ambiguous requirements into structures that teams can understand, build, test, and improve.
```

**Descriptor**

```text
Information Systems × Data × Product
```

### Tiếng Việt

**Identity label**

```text
NGUYỄN MINH TRÚC
```

**Heading**

```text
Thiết kế hệ thống và sản phẩm dựa trên dữ liệu.
```

**Lead**

```text
Tôi chuyển các yêu cầu chưa rõ ràng thành cấu trúc mà đội ngũ có thể hiểu, triển khai, kiểm thử và cải tiến.
```

**Descriptor**

```text
Hệ thống Thông tin × Dữ liệu × Sản phẩm
```

## 3. About

### English title

```text
About Nguyen Minh Truc
```

### Vietnamese title

```text
Về Nguyễn Minh Trúc
```

### English introductory paragraph

```text
I am an Information Systems student working across data analysis, system analysis, and product development. My portfolio focuses on how requirements, data, architecture, and user outcomes connect—not on presenting isolated tools as expertise.
```

### Vietnamese introductory paragraph

```text
Tôi là Nguyễn Minh Trúc, sinh viên Hệ thống thông tin, tập trung vào phân tích dữ liệu, phân tích hệ thống và phát triển sản phẩm. Portfolio này trình bày mối liên hệ giữa yêu cầu, dữ liệu, kiến trúc và kết quả người dùng, thay vì liệt kê công cụ như những năng lực tách rời.
```

## 4. Contact

### English

```text
Have a system, data, or product problem that requires structured analysis? Contact me with the context, constraints, and expected outcome.
```

### Tiếng Việt

```text
Bạn có một bài toán hệ thống, dữ liệu hoặc sản phẩm cần được phân tích có cấu trúc? Hãy gửi bối cảnh, ràng buộc và kết quả mong đợi.
```

Email hiển thị và email thực tế đều là:

```text
nmtruc.work@gmail.com
```

## 5. Footer

### English

```text
© 2026 Nguyen Minh Truc. All rights reserved.
```

### Tiếng Việt

```text
© 2026 Nguyễn Minh Trúc. Giữ toàn bộ bản quyền.
```

## 6. SEO title format

### Home

```text
Nguyễn Minh Trúc — Information Systems, Data & Product
```

### Work

```text
Selected Work — Nguyễn Minh Trúc
```

### Project

```text
{Project title} — Nguyễn Minh Trúc
```

### About

```text
About Nguyễn Minh Trúc
```

## 7. Giọng văn

- Dùng động từ mô tả hành động: defined, modeled, analyzed, implemented, evaluated.
- Không tự nhận “expert”, “specialist”, “highly skilled” nếu chưa có bằng chứng độc lập.
- Phân biệt rõ `designed`, `implemented`, `tested`, `deployed` và `operated`.
- Không dùng “we” cho dự án cá nhân; không dùng “I” cho phần việc của cả đội.
- Mỗi case study phải chỉ rõ phạm vi đóng góp cá nhân.
