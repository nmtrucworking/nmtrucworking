# Hướng dẫn migration dữ liệu

## 1. Nguyên tắc

Source of truth của danh tính phải nằm trong `profile.json` và `site.json`. Component chỉ render dữ liệu; không hard-code lại tên trừ fallback accessibility.

## 2. Thứ tự thay file

```bash
cp proposed/src/content/data/profile.json src/content/data/profile.json
cp proposed/src/content/data/messages.en.json src/content/data/messages.en.json
cp proposed/src/content/data/messages.vi.json src/content/data/messages.vi.json
```

Với `site.template.json`, phải thay `REPLACE_WITH_PRODUCTION_DOMAIN` trước rồi mới copy.

## 3. Đổi tên CV

```bash
mv public/cv/jin-cv-en.pdf public/cv/nguyen-minh-truc-cv-en.pdf
mv public/cv/jin-cv-vi.pdf public/cv/nguyen-minh-truc-cv-vi.pdf
```

Nếu file CV chưa tồn tại, không tạo file giả. Giữ trang CV ở trạng thái `coming soon` hoặc ẩn CTA tải xuống cho đến khi có artifact thật.

## 4. Thay SEO title trong projects

Dùng script có review diff:

```bash
python -c "from pathlib import Path; p=Path('src/content/data/projects.json'); s=p.read_text(encoding='utf-8').replace('— Jin','— Nguyễn Minh Trúc'); p.write_text(s, encoding='utf-8')"
git diff -- src/content/data/projects.json
```

Không tự động thay metric hoặc project status.

## 5. Domain configuration

Khuyến nghị đưa domain vào environment:

```env
NEXT_PUBLIC_SITE_URL=https://your-production-domain.example
```

Sau đó metadata và JSON-LD đọc từ biến này. Nếu `site.json` vẫn cần `baseUrl`, build script nên kiểm tra `baseUrl` trùng `NEXT_PUBLIC_SITE_URL` ở production.

## 6. Validation

```bash
npm run validate-data
npm run build
```

Nếu JSON schema thất bại:

- kiểm tra URI có scheme `https://`;
- kiểm tra `id` chỉ dùng chữ thường, số và dấu gạch ngang;
- không thêm property ngoài schema;
- giữ đủ hai locale `en` và `vi`.

## 7. Data ownership rule

Các trường sau không được trùng lặp ở nhiều file nếu không cần thiết:

- tên cá nhân;
- email;
- GitHub URL;
- LinkedIn URL;
- base URL.

Ở vòng cải tiến tiếp theo, nên tạo một selector hoặc config chung cho metadata để giảm drift giữa `profile.json`, `site.json` và `layout.tsx`.
