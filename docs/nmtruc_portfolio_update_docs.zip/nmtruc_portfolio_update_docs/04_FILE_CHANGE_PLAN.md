# Kế hoạch thay đổi theo file

## 1. `src/content/data/site.json`

Dùng file mẫu tại:

```text
proposed/src/content/data/site.template.json
```

Điểm bắt buộc:

- `siteName`: `Nguyễn Minh Trúc — Portfolio`
- `baseUrl`: thay bằng domain production thật trước khi merge.
- Chỉ giữ social link đã xác minh.

## 2. `src/content/data/profile.json`

Dùng file mẫu:

```text
proposed/src/content/data/profile.json
```

Đổi asset CV:

```text
public/cv/jin-cv-en.pdf
→ public/cv/nguyen-minh-truc-cv-en.pdf

public/cv/jin-cv-vi.pdf
→ public/cv/nguyen-minh-truc-cv-vi.pdf
```

## 3. `messages.en.json` và `messages.vi.json`

Có file thay thế đầy đủ trong `proposed/`. Các thay đổi trọng yếu:

- `About Jin` → `About Nguyen Minh Truc`
- `Về Jin` → `Về Nguyễn Minh Trúc`
- bỏ email `hello@jin-systems.dev`
- rút gọn nhãn CTA, tránh ngôn ngữ agency quá mức như “Initiate Contact”.

## 4. `src/app/layout.tsx`

Dùng snippet:

```text
snippets/layout.metadata.ts
```

Nên mở rộng metadata bằng `metadataBase`, template title, Open Graph, Twitter card và authors.

## 5. `src/components/layout/Header.tsx`

Thay block brand mark bằng snippet:

```text
snippets/Header.brand.tsx
```

Không thay đổi navigation hoặc locale switcher.

## 6. `src/app/[locale]/page.tsx`

Thay phần đầu hero theo cấu trúc:

```tsx
<p className="mono-label">{profile.displayName}</p>
<h1>{localized hero heading}</h1>
<p>{profile.positioningText}</p>
```

Thay nhãn ảnh:

```text
OPERATOR // NMTRUC
→ PROFILE // NGUYEN_MINH_TRUC
```

`alt` phải luôn nhận `profile.displayName`; fallback là `Nguyễn Minh Trúc`.

## 7. `src/components/layout/Footer.tsx`

Thay copyright:

```tsx
© {new Date().getFullYear()} {profile.displayName}. {messages.footer.rights}
```

Không hard-code tên trong component khi dữ liệu profile đã có.

## 8. `src/content/data/projects.json`

Thực hiện thay thế có kiểm soát:

```text
— Jin
→ — Nguyễn Minh Trúc
```

Sau đó rà soát từng project:

- URL repository có trỏ đúng repo dự án không.
- `stage` có phản ánh thực tế không.
- Metric có nguồn kiểm chứng không.
- `team.size` và contribution có chính xác không.

Không chạy global replace cho các từ “jin” nằm trong URL lịch sử nếu URL đó thực sự cần giữ. Tuy nhiên `jin-systems.dev` phải bị loại bỏ hoàn toàn.

## 9. `package.json`

```json
{
  "name": "nmtruc-portfolio"
}
```

Sau đó chạy:

```bash
npm install
```

để đồng bộ `package-lock.json`.

## 10. Tài liệu nội bộ

Đổi:

```text
JIN_Portfolio_Implementation_Docs/jin-portfolio-docs/
```

thành:

```text
docs/portfolio/
```

Các file trong thư mục cũ phải được cập nhật theo `01_IDENTITY_ARCHITECTURE.md`; không chỉ đổi tên thư mục.

## 11. README

Dùng nội dung mẫu:

```text
snippets/README.replacement.md
```

## 12. Commit đề xuất

```text
chore(identity): replace JIN branding with Nguyen Minh Truc identity
```
