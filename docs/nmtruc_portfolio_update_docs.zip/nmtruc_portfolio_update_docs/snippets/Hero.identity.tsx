<div className="space-y-3">
  <p className="mono-label text-xs text-muted tracking-[0.18em] uppercase">{profile.displayName}</p>
  <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-ink leading-[1.08]">
    {locale === 'en' ? 'Designing data-informed systems and products.' : 'Thiết kế hệ thống và sản phẩm dựa trên dữ liệu.'}
  </h1>
</div>
<p className="text-xl sm:text-2xl text-muted font-light leading-relaxed max-w-2xl">{profile.positioningText}</p>
