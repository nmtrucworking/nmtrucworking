# Nguyễn Minh Trúc (@nmtrucworking)

### Information Systems × Data × Product

> Turning ambiguous requirements into structures teams can understand, build, test, and improve.

## About

I am an Information Systems student working across data analysis, system analysis, and product development. This repository contains my bilingual portfolio and selected case studies.

My work is organized around a simple systems method:

```text
INPUT → INTERPRET → STRUCTURE → BUILD → EVALUATE
```

## Focus areas

- Data analysis and analytical modeling
- Requirements and business analysis
- System architecture and integration
- Applied machine learning
- Product framing and validation

## Portfolio stack

- Next.js 14
- React 18
- TypeScript
- Tailwind CSS
- JSON Schema validation with AJV

## Contact

- Email: [nmtruc.work@gmail.com](mailto:nmtruc.work@gmail.com)
- LinkedIn: [Nguyễn Minh Trúc](https://www.linkedin.com/in/minh-truc-nguyen/)
- GitHub: [@nmtrucworking](https://github.com/nmtrucworking)

## Local development

```bash
git clone git@github.com:nmtrucworking/nmtrucworking.git
cd nmtrucworking
npm install
npm run validate-data
npm run dev
npm run build
```

---

Maintained by Nguyễn Minh Trúc.
