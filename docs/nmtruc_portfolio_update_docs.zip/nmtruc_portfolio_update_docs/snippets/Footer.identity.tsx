<div>
  © {new Date().getFullYear()} {profile.displayName}. {messages.footer.rights}
</div>
