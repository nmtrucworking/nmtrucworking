{/* Identity wordmark — replaces the current identity block */}
<Link href={`/${locale}`} className="group flex items-center gap-3" aria-label="Nguyễn Minh Trúc — Home">
  <div className="w-9 h-9 rounded bg-graphite flex items-center justify-center text-signal font-mono font-bold text-xs group-hover:scale-105 transition-transform">NM</div>
  <div className="flex flex-col">
    <span className="font-display font-bold text-ink text-lg leading-tight tracking-tight">NMTRUC</span>
    <span className="mono-label text-[10px] text-muted tracking-widest uppercase">Personal Portfolio</span>
  </div>
</Link>
