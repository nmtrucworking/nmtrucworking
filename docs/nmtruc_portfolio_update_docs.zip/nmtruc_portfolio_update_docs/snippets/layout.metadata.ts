import type { Metadata } from 'next';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000';

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Nguyễn Minh Trúc — Information Systems, Data & Product',
    template: '%s — Nguyễn Minh Trúc',
  },
  description: 'Bilingual portfolio of Nguyễn Minh Trúc, focused on information systems, data analysis, system analysis, and product development.',
  authors: [{ name: 'Nguyễn Minh Trúc' }],
  creator: 'Nguyễn Minh Trúc',
  keywords: ['Nguyễn Minh Trúc', 'Nguyen Minh Truc', 'nmtrucworking', 'Information Systems', 'Data Analyst', 'System Analyst', 'Business Analyst', 'Data Science', 'Product'],
  openGraph: {
    type: 'website',
    siteName: 'Nguyễn Minh Trúc — Portfolio',
    title: 'Nguyễn Minh Trúc — Information Systems, Data & Product',
    description: 'Selected work across information systems, data, system analysis, and product development.',
    url: siteUrl,
    locale: 'en_US',
    alternateLocale: ['vi_VN'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nguyễn Minh Trúc — Information Systems, Data & Product',
    description: 'Selected work across information systems, data, system analysis, and product development.',
  },
};
