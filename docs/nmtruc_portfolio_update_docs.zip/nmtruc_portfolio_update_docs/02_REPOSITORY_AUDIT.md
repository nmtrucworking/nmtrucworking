# Rà soát repo hiện tại

## 1. Kết luận chính

Mã nguồn hiện tại đã triển khai một hệ thống dữ liệu tương đối rõ, nhưng danh tính `JIN` bị hard-code ở nhiều lớp: cấu hình site, profile, bản dịch, component, metadata, SEO dự án, package và tài liệu nội bộ. Chỉ thay logo sẽ không giải quyết triệt để.

## 2. Kiểm kê theo file

| File | Hiện trạng | Thay đổi bắt buộc |
|---|---|---|
| `src/content/data/site.json` | `siteName: "JIN / Systems in Motion"`, domain `jin-systems.dev` | Đổi site name; thay production domain thật; loại social placeholder |
| `src/content/data/profile.json` | `id: "jin"`, `displayName: "Jin"`, CV tên `jin-cv-*` | Đổi thành `nguyen-minh-truc`, tên đầy đủ và tên file CV mới |
| `src/content/data/messages.en.json` | `About Jin`, email lỗi dùng `hello@jin-systems.dev` | Đổi About title và dùng email thật |
| `src/content/data/messages.vi.json` | `Về Jin`, email lỗi dùng `hello@jin-systems.dev` | Đổi thành `Về Nguyễn Minh Trúc`; dùng email thật |
| `src/app/layout.tsx` | metadata title hard-code `JIN / Systems in Motion` | Dùng tên thật và metadata template |
| `src/components/layout/Header.tsx` | monogram `J`, wordmark `JIN` | Dùng `NM`/`NMTRUC` |
| `src/components/layout/Footer.tsx` | copyright `JIN` | Dùng Nguyễn Minh Trúc |
| `src/app/[locale]/page.tsx` | ảnh đã dùng `nmtruc.png`, nhãn `OPERATOR // NMTRUC`; hero chưa hiển thị tên đầy đủ | Thêm identity label/tên đầy đủ; chuẩn hóa nhãn ảnh |
| `src/content/data/projects.json` | nhiều `seoTitle` kết thúc bằng `— Jin` | Đổi thành `— Nguyễn Minh Trúc` |
| `README.md` | “I'm Jin”, email/LinkedIn label giả định | Viết lại theo tên thật và URL thật |
| `package.json` | `name: "jin-portfolio"` | Đổi thành `nmtruc-portfolio` |
| `package-lock.json` | giữ package name cũ | Chạy `npm install` sau khi đổi package |
| `JIN_Portfolio_Implementation_Docs/` | tên thư mục và nội dung neo vào JIN | Đổi thành `docs/portfolio/` và cập nhật nội dung |

## 3. Social link không nên giữ nếu chưa dùng

`site.json` hiện chứa Twitter, Instagram và Facebook. Nếu các kênh này không phục vụ mục tiêu nghề nghiệp hoặc URL chỉ là placeholder, nên xóa khỏi dữ liệu thay vì để liên kết rỗng/không chính xác.

Kênh tối thiểu:

- GitHub
- LinkedIn
- Email

## 4. Rủi ro nội dung ngoài phạm vi tên gọi

Một số case study dùng:

- trạng thái `production`;
- chỉ số tác động kinh doanh cụ thể;
- số đo hiệu năng/kiểm thử;
- mô tả như một hệ thống đã vận hành thực tế.

Nếu các số liệu là dữ liệu minh họa, mô phỏng hoặc mục tiêu thiết kế, chúng phải được gắn nhãn tương ứng. Portfolio cá nhân chịu rủi ro lớn hơn từ một claim không chứng minh được so với việc thiếu một metric.

## 5. Mức ưu tiên

### P0 — chặn phát hành

- Tên người, metadata, CV, email hiển thị.
- Các liên kết giả/placeholder.
- Metric hoặc trạng thái dự án sai bản chất.

### P1 — cần hoàn thành trong cùng nhánh

- Header, Footer, README, project SEO titles.
- Package name và docs directory.

### P2 — cải thiện tiếp theo

- Structured data.
- Sitemap/canonical theo locale.
- Chuẩn hóa author và evidence model trong schema.
