# SEO, metadata và social identity

## 1. Mục tiêu

Công cụ tìm kiếm phải nhận biết portfolio thuộc về **một cá nhân cụ thể**, không phải một thương hiệu tên JIN.

## 2. Metadata chuẩn

```ts
export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL!),
  title: {
    default: 'Nguyễn Minh Trúc — Information Systems, Data & Product',
    template: '%s — Nguyễn Minh Trúc',
  },
  description:
    'Bilingual portfolio of Nguyễn Minh Trúc, focused on information systems, data analysis, system analysis, and product development.',
  authors: [{ name: 'Nguyễn Minh Trúc' }],
  creator: 'Nguyễn Minh Trúc',
  keywords: [
    'Nguyễn Minh Trúc',
    'Nguyen Minh Truc',
    'nmtrucworking',
    'Information Systems',
    'Data Analyst',
    'System Analyst',
    'Business Analyst',
    'Data Science',
  ],
};
```

Không dùng `!` với biến môi trường nếu build pipeline chưa đảm bảo biến luôn tồn tại. Có thể dùng fallback local cho development, nhưng production phải fail nếu thiếu canonical URL.

## 3. Canonical và locale

Mỗi route cần:

- canonical URL;
- alternate `en` và `vi`;
- `x-default` trỏ về locale mặc định;
- Open Graph locale tương ứng.

Ví dụ logic:

```ts
alternates: {
  canonical: `/${locale}`,
  languages: {
    en: '/en',
    vi: '/vi',
    'x-default': '/en',
  },
}
```

## 4. Person structured data

```json
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Nguyễn Minh Trúc",
  "alternateName": ["Nguyen Minh Truc", "NMTRUC", "nmtrucworking"],
  "email": "mailto:nmtruc.work@gmail.com",
  "url": "REPLACE_WITH_PRODUCTION_URL",
  "sameAs": [
    "https://github.com/nmtrucworking",
    "https://www.linkedin.com/in/minh-truc-nguyen/"
  ],
  "knowsAbout": [
    "Information Systems",
    "Data Analysis",
    "System Analysis",
    "Business Analysis",
    "Data Science",
    "Product Development"
  ]
}
```

Không thêm trường `jobTitle` chứa năm vai trò cùng lúc. Điều đó làm định vị thiếu trọng tâm. Có thể dùng mô tả rộng ở `description`, còn từng case study thể hiện role lens.

## 5. Open Graph image

Ảnh OG nên có:

- Nguyễn Minh Trúc
- `Information Systems × Data × Product`
- URL/handle `nmtrucworking`
- không dùng logo JIN

Kích thước: `1200 × 630`.

## 6. Social profile consistency

| Nền tảng | Display name | Handle/URL |
|---|---|---|
| Portfolio | Nguyễn Minh Trúc | production domain |
| GitHub | Nguyễn Minh Trúc | `nmtrucworking` |
| LinkedIn | Nguyễn Minh Trúc | existing LinkedIn URL |
| Email | Nguyễn Minh Trúc | `nmtruc.work@gmail.com` |

Avatar, headline và short bio nên dùng cùng một ảnh chân dung và cùng ba trụ cột định vị.

## 7. Domain

Không phát hành với `jin-systems.dev` nếu domain đó không còn là định danh chiến lược hoặc chưa thuộc quyền kiểm soát.

Tiêu chí chọn domain:

1. chứa `nmtruc`, `minhtruc` hoặc tên đầy đủ;
2. dễ đọc khi nói thành tiếng;
3. không cần giải thích quan hệ với tên thật;
4. có thể dùng đồng nhất trong email và social bio;
5. đã xác minh quyền sở hữu trước khi đưa vào metadata.
